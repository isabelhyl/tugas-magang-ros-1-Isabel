// Auto-generated. Do not edit!

// (in-package trip_management.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SearchTripRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tripID = null;
      this.destination = null;
      this.date = null;
      this.price = null;
    }
    else {
      if (initObj.hasOwnProperty('tripID')) {
        this.tripID = initObj.tripID
      }
      else {
        this.tripID = 0;
      }
      if (initObj.hasOwnProperty('destination')) {
        this.destination = initObj.destination
      }
      else {
        this.destination = '';
      }
      if (initObj.hasOwnProperty('date')) {
        this.date = initObj.date
      }
      else {
        this.date = '';
      }
      if (initObj.hasOwnProperty('price')) {
        this.price = initObj.price
      }
      else {
        this.price = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SearchTripRequest
    // Serialize message field [tripID]
    bufferOffset = _serializer.int32(obj.tripID, buffer, bufferOffset);
    // Serialize message field [destination]
    bufferOffset = _serializer.string(obj.destination, buffer, bufferOffset);
    // Serialize message field [date]
    bufferOffset = _serializer.string(obj.date, buffer, bufferOffset);
    // Serialize message field [price]
    bufferOffset = _serializer.float64(obj.price, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SearchTripRequest
    let len;
    let data = new SearchTripRequest(null);
    // Deserialize message field [tripID]
    data.tripID = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [destination]
    data.destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date]
    data.date = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [price]
    data.price = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.destination);
    length += _getByteLength(object.date);
    return length + 20;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/SearchTripRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8f2da5cb4caaac7d400a01199f8ada06';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # srv/SearchTrip.srv
    int32 tripID
    string destination
    string date
    float64 price
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SearchTripRequest(null);
    if (msg.tripID !== undefined) {
      resolved.tripID = msg.tripID;
    }
    else {
      resolved.tripID = 0
    }

    if (msg.destination !== undefined) {
      resolved.destination = msg.destination;
    }
    else {
      resolved.destination = ''
    }

    if (msg.date !== undefined) {
      resolved.date = msg.date;
    }
    else {
      resolved.date = ''
    }

    if (msg.price !== undefined) {
      resolved.price = msg.price;
    }
    else {
      resolved.price = 0.0
    }

    return resolved;
    }
};

class SearchTripResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.search_results = null;
    }
    else {
      if (initObj.hasOwnProperty('search_results')) {
        this.search_results = initObj.search_results
      }
      else {
        this.search_results = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SearchTripResponse
    // Serialize message field [search_results]
    bufferOffset = _serializer.string(obj.search_results, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SearchTripResponse
    let len;
    let data = new SearchTripResponse(null);
    // Deserialize message field [search_results]
    data.search_results = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.search_results);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/SearchTripResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c603cc73e615cba26b0df9876dab221e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string search_results  
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SearchTripResponse(null);
    if (msg.search_results !== undefined) {
      resolved.search_results = msg.search_results;
    }
    else {
      resolved.search_results = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SearchTripRequest,
  Response: SearchTripResponse,
  md5sum() { return 'f045567d67a301bd9da2c6997176c1cf'; },
  datatype() { return 'trip_management/SearchTrip'; }
};
