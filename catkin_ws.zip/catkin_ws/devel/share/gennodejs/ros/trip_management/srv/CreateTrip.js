// Auto-generated. Do not edit!

// (in-package trip_management.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class CreateTripRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.destination = null;
      this.date = null;
      this.price = null;
    }
    else {
      if (initObj.hasOwnProperty('destination')) {
        this.destination = initObj.destination
      }
      else {
        this.destination = '';
      }
      if (initObj.hasOwnProperty('date')) {
        this.date = initObj.date
      }
      else {
        this.date = '';
      }
      if (initObj.hasOwnProperty('price')) {
        this.price = initObj.price
      }
      else {
        this.price = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CreateTripRequest
    // Serialize message field [destination]
    bufferOffset = _serializer.string(obj.destination, buffer, bufferOffset);
    // Serialize message field [date]
    bufferOffset = _serializer.string(obj.date, buffer, bufferOffset);
    // Serialize message field [price]
    bufferOffset = _serializer.float64(obj.price, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CreateTripRequest
    let len;
    let data = new CreateTripRequest(null);
    // Deserialize message field [destination]
    data.destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date]
    data.date = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [price]
    data.price = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.destination);
    length += _getByteLength(object.date);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/CreateTripRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '452f916d43f72f572ce68396ac261f8e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # srv/CreateTrip.srv
    string destination
    string date
    float64 price
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CreateTripRequest(null);
    if (msg.destination !== undefined) {
      resolved.destination = msg.destination;
    }
    else {
      resolved.destination = ''
    }

    if (msg.date !== undefined) {
      resolved.date = msg.date;
    }
    else {
      resolved.date = ''
    }

    if (msg.price !== undefined) {
      resolved.price = msg.price;
    }
    else {
      resolved.price = 0.0
    }

    return resolved;
    }
};

class CreateTripResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tripID = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('tripID')) {
        this.tripID = initObj.tripID
      }
      else {
        this.tripID = 0;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CreateTripResponse
    // Serialize message field [tripID]
    bufferOffset = _serializer.int32(obj.tripID, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CreateTripResponse
    let len;
    let data = new CreateTripResponse(null);
    // Deserialize message field [tripID]
    data.tripID = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/CreateTripResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e944beb0419409f12a7a5678a928976a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 tripID
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CreateTripResponse(null);
    if (msg.tripID !== undefined) {
      resolved.tripID = msg.tripID;
    }
    else {
      resolved.tripID = 0
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: CreateTripRequest,
  Response: CreateTripResponse,
  md5sum() { return '3e9bd3e19f836c3b68086c5a045c9af9'; },
  datatype() { return 'trip_management/CreateTrip'; }
};
