// Auto-generated. Do not edit!

// (in-package trip_management.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class DisplayTripsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DisplayTripsRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DisplayTripsRequest
    let len;
    let data = new DisplayTripsRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/DisplayTripsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # srv/DisplayTrips.srv
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DisplayTripsRequest(null);
    return resolved;
    }
};

class DisplayTripsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.trips = null;
    }
    else {
      if (initObj.hasOwnProperty('trips')) {
        this.trips = initObj.trips
      }
      else {
        this.trips = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DisplayTripsResponse
    // Serialize message field [trips]
    bufferOffset = _serializer.string(obj.trips, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DisplayTripsResponse
    let len;
    let data = new DisplayTripsResponse(null);
    // Deserialize message field [trips]
    data.trips = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.trips);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/DisplayTripsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0f84fcdc30d3bef7b5e8d85b550a5446';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string trips 
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DisplayTripsResponse(null);
    if (msg.trips !== undefined) {
      resolved.trips = msg.trips;
    }
    else {
      resolved.trips = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: DisplayTripsRequest,
  Response: DisplayTripsResponse,
  md5sum() { return '0f84fcdc30d3bef7b5e8d85b550a5446'; },
  datatype() { return 'trip_management/DisplayTrips'; }
};
