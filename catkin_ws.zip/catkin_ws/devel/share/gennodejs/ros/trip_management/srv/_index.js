
"use strict";

let DeleteTrip = require('./DeleteTrip.js')
let SearchTrip = require('./SearchTrip.js')
let UpdateTrip = require('./UpdateTrip.js')
let DisplayTrips = require('./DisplayTrips.js')
let CreateTrip = require('./CreateTrip.js')

module.exports = {
  DeleteTrip: DeleteTrip,
  SearchTrip: SearchTrip,
  UpdateTrip: UpdateTrip,
  DisplayTrips: DisplayTrips,
  CreateTrip: CreateTrip,
};
