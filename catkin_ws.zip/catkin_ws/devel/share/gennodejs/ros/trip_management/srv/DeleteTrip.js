// Auto-generated. Do not edit!

// (in-package trip_management.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class DeleteTripRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tripID = null;
    }
    else {
      if (initObj.hasOwnProperty('tripID')) {
        this.tripID = initObj.tripID
      }
      else {
        this.tripID = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DeleteTripRequest
    // Serialize message field [tripID]
    bufferOffset = _serializer.int32(obj.tripID, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DeleteTripRequest
    let len;
    let data = new DeleteTripRequest(null);
    // Deserialize message field [tripID]
    data.tripID = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/DeleteTripRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1558d3a6c2589d3956dfe4e7aede53a6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # srv/DeleteTrip.srv
    int32 tripID
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DeleteTripRequest(null);
    if (msg.tripID !== undefined) {
      resolved.tripID = msg.tripID;
    }
    else {
      resolved.tripID = 0
    }

    return resolved;
    }
};

class DeleteTripResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DeleteTripResponse
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DeleteTripResponse
    let len;
    let data = new DeleteTripResponse(null);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/DeleteTripResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5f003d6bcc824cbd51361d66d8e4f76c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DeleteTripResponse(null);
    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: DeleteTripRequest,
  Response: DeleteTripResponse,
  md5sum() { return '4347fb7c93088680b3199b17aa270a29'; },
  datatype() { return 'trip_management/DeleteTrip'; }
};
