// Auto-generated. Do not edit!

// (in-package trip_management.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class UpdateTripRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tripID = null;
      this.new_destination = null;
      this.new_date = null;
      this.new_price = null;
    }
    else {
      if (initObj.hasOwnProperty('tripID')) {
        this.tripID = initObj.tripID
      }
      else {
        this.tripID = 0;
      }
      if (initObj.hasOwnProperty('new_destination')) {
        this.new_destination = initObj.new_destination
      }
      else {
        this.new_destination = '';
      }
      if (initObj.hasOwnProperty('new_date')) {
        this.new_date = initObj.new_date
      }
      else {
        this.new_date = '';
      }
      if (initObj.hasOwnProperty('new_price')) {
        this.new_price = initObj.new_price
      }
      else {
        this.new_price = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UpdateTripRequest
    // Serialize message field [tripID]
    bufferOffset = _serializer.int32(obj.tripID, buffer, bufferOffset);
    // Serialize message field [new_destination]
    bufferOffset = _serializer.string(obj.new_destination, buffer, bufferOffset);
    // Serialize message field [new_date]
    bufferOffset = _serializer.string(obj.new_date, buffer, bufferOffset);
    // Serialize message field [new_price]
    bufferOffset = _serializer.float32(obj.new_price, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UpdateTripRequest
    let len;
    let data = new UpdateTripRequest(null);
    // Deserialize message field [tripID]
    data.tripID = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [new_destination]
    data.new_destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [new_date]
    data.new_date = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [new_price]
    data.new_price = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.new_destination);
    length += _getByteLength(object.new_date);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/UpdateTripRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7c9bd6d516336578672f3c949f438f37';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 tripID
    string new_destination
    string new_date
    float32 new_price
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UpdateTripRequest(null);
    if (msg.tripID !== undefined) {
      resolved.tripID = msg.tripID;
    }
    else {
      resolved.tripID = 0
    }

    if (msg.new_destination !== undefined) {
      resolved.new_destination = msg.new_destination;
    }
    else {
      resolved.new_destination = ''
    }

    if (msg.new_date !== undefined) {
      resolved.new_date = msg.new_date;
    }
    else {
      resolved.new_date = ''
    }

    if (msg.new_price !== undefined) {
      resolved.new_price = msg.new_price;
    }
    else {
      resolved.new_price = 0.0
    }

    return resolved;
    }
};

class UpdateTripResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UpdateTripResponse
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UpdateTripResponse
    let len;
    let data = new UpdateTripResponse(null);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'trip_management/UpdateTripResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5f003d6bcc824cbd51361d66d8e4f76c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UpdateTripResponse(null);
    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: UpdateTripRequest,
  Response: UpdateTripResponse,
  md5sum() { return '1297b359abda49568be02beb778b4988'; },
  datatype() { return 'trip_management/UpdateTrip'; }
};
