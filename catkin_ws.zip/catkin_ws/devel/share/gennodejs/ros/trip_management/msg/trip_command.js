// Auto-generated. Do not edit!

// (in-package trip_management.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class trip_command {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.command = null;
      this.tripID = null;
      this.destination = null;
      this.date = null;
      this.price = null;
    }
    else {
      if (initObj.hasOwnProperty('command')) {
        this.command = initObj.command
      }
      else {
        this.command = '';
      }
      if (initObj.hasOwnProperty('tripID')) {
        this.tripID = initObj.tripID
      }
      else {
        this.tripID = 0;
      }
      if (initObj.hasOwnProperty('destination')) {
        this.destination = initObj.destination
      }
      else {
        this.destination = '';
      }
      if (initObj.hasOwnProperty('date')) {
        this.date = initObj.date
      }
      else {
        this.date = '';
      }
      if (initObj.hasOwnProperty('price')) {
        this.price = initObj.price
      }
      else {
        this.price = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type trip_command
    // Serialize message field [command]
    bufferOffset = _serializer.string(obj.command, buffer, bufferOffset);
    // Serialize message field [tripID]
    bufferOffset = _serializer.int32(obj.tripID, buffer, bufferOffset);
    // Serialize message field [destination]
    bufferOffset = _serializer.string(obj.destination, buffer, bufferOffset);
    // Serialize message field [date]
    bufferOffset = _serializer.string(obj.date, buffer, bufferOffset);
    // Serialize message field [price]
    bufferOffset = _serializer.float64(obj.price, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type trip_command
    let len;
    let data = new trip_command(null);
    // Deserialize message field [command]
    data.command = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [tripID]
    data.tripID = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [destination]
    data.destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date]
    data.date = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [price]
    data.price = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.command);
    length += _getByteLength(object.destination);
    length += _getByteLength(object.date);
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'trip_management/trip_command';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5912eb6bfaddc1ee3c4687c43d43215c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # trip_management/msg/trip_command.msg
    
    string command  # e.g., "create", "display", "update", "delete"
    int32 tripID
    string destination
    string date
    float64 price
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new trip_command(null);
    if (msg.command !== undefined) {
      resolved.command = msg.command;
    }
    else {
      resolved.command = ''
    }

    if (msg.tripID !== undefined) {
      resolved.tripID = msg.tripID;
    }
    else {
      resolved.tripID = 0
    }

    if (msg.destination !== undefined) {
      resolved.destination = msg.destination;
    }
    else {
      resolved.destination = ''
    }

    if (msg.date !== undefined) {
      resolved.date = msg.date;
    }
    else {
      resolved.date = ''
    }

    if (msg.price !== undefined) {
      resolved.price = msg.price;
    }
    else {
      resolved.price = 0.0
    }

    return resolved;
    }
};

module.exports = trip_command;
