# src/subscriber_node.py
import rospy
from trip_management.srv import CreateTrip, CreateTripResponse
from trip_management.srv import DisplayTrips, DisplayTripsResponse
from trip_management.srv import UpdateTrip, UpdateTripResponse
from trip_management.srv import DeleteTrip, DeleteTripResponse
from trip_management.srv import SearchTrip, SearchTripResponse

trips = []  
next_trip_id = 1 

def handle_create_trip(request):
    rospy.loginfo(f"Received create trip request: {request}")
    global next_trip_id
    trip = {
        "tripID": next_trip_id,
        "destination": request.destination,
        "date": request.date,
        "price": request.price
    }
    trips.append(trip)
    next_trip_id += 1
    rospy.loginfo("Trip created successfully.")
    return CreateTripResponse(next_trip_id - 1, "Trip created successfully")


def handle_display_trips(request):
    if not trips:
        rospy.loginfo("No trips available")
        return DisplayTripsResponse("No trips available")
    
    response_message = "\n".join(
        [f"Trip ID: {trip['tripID']}, Destination: {trip['destination']}, Date: {trip['date']}, Price: {trip['price']}" for trip in trips]
    )
    rospy.loginfo(response_message)
    return DisplayTripsResponse(response_message) 


def handle_update_trip(request):
    for trip in trips:
        if trip["tripID"] == request.tripID:
            if request.new_destination:
                trip["destination"] = request.new_destination
            if request.new_date:
                trip["date"] = request.new_date
            if request.new_price >= 0:
                trip["price"] = request.new_price
            rospy.loginfo("Trip updated successfully")
            return UpdateTripResponse("Trip updated successfully")
    rospy.loginfo("Trip ID not found")
    return UpdateTripResponse("Trip ID not found")

def handle_delete_trip(request):
    global trips
    for trip in trips:
        if trip["tripID"] == request.tripID:
            trips.remove(trip)
            rospy.loginfo("Trip deleted successfully")
            return DeleteTripResponse("Trip deleted successfully")
    rospy.loginfo("Trip ID not found")
    return DeleteTripResponse("Trip ID not found")

def handle_search_trip(request):
    results = []
    for trip in trips:
        if (request.tripID and trip["tripID"] == request.tripID) or \
           (request.destination and trip["destination"] == request.destination) or \
           (request.date and trip["date"] == request.date) or \
           (request.price >= 0 and trip["price"] == request.price):
            results.append(trip)
    if not results:
        return SearchTripResponse("No matching trips found")

    response_message = "\n".join(
        [f"Trip ID: {trip['tripID']}, Destination: {trip['destination']}, Date: {trip['date']}, Price: {trip['price']}" for trip in results]
    )
    return SearchTripResponse(response_message)

def main():
    rospy.init_node('trip_subscriber')

    create_trip_service = rospy.Service('create_trip', CreateTrip, handle_create_trip)
    display_trips_service = rospy.Service('display_trips', DisplayTrips, handle_display_trips)
    update_trip_service = rospy.Service('update_trip', UpdateTrip, handle_update_trip)
    delete_trip_service = rospy.Service('delete_trip', DeleteTrip, handle_delete_trip)
    search_trip_service = rospy.Service('search_trip', SearchTrip, handle_search_trip)
    
    rospy.loginfo("Trip Management Services are ready.")
    rospy.spin()  

if __name__ == "__main__":
    main()