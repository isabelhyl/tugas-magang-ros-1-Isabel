# src/publisher_node.py
import rospy
from trip_management.srv import CreateTrip, DisplayTrips, UpdateTrip, DeleteTrip, SearchTrip
from std_msgs.msg import String


trips = []

def create_trip_client(destination, date, price):
    rospy.wait_for_service('create_trip')
    try:
        create_trip = rospy.ServiceProxy('create_trip', CreateTrip)
        response = create_trip(destination, date, price)
        print(response.message)
    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")

def display_trips_client():
    rospy.wait_for_service('display_trips')
    try:
        display_trips = rospy.ServiceProxy('display_trips', DisplayTrips)
        response = display_trips()
        print(response.trips)
    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")


def update_trip_client(trip_id, new_destination, new_date, new_price):
    rospy.wait_for_service('update_trip')
    try:
        update_trip = rospy.ServiceProxy('update_trip', UpdateTrip)
        response = update_trip(trip_id, new_destination, new_date, new_price)
        print(response.message)
    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")


def delete_trip_client(trip_id):
    rospy.wait_for_service('delete_trip')
    try:
        delete_trip = rospy.ServiceProxy('delete_trip', DeleteTrip)
        response = delete_trip(trip_id)
        print(response.message)
    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")

def search_trip_client():
    rospy.wait_for_service('search_trip')
    try:
        search_trip = rospy.ServiceProxy('search_trip', SearchTrip)
        
        print("\n--- Search Options ---")
        print("1. Search by Trip ID")
        print("2. Search by Destination")
        print("3. Search by Price")
        print("4. Search by Date")

        input_choices = input("Enter your choice(s): ")
        choices = list(map(int, input_choices.split())) 

       
        trip_id = 0   
        destination = ""
        price = 0.0
        date = ""
        for choice in choices:
            if choice == 1:
                trip_id = int(input("Enter Trip ID: "))
            elif choice == 2:
                destination = input("Enter Destination: ")
            elif choice == 3:
                price = float(input("Enter Price: "))
            elif choice == 4:
                date = input("Enter Date (YYYY-MM-DD): ")
            else:
                print(f"Invalid choice: {choice}. Please choose between 1 and 4.")

       
        response = search_trip(tripID=trip_id,
                               destination=destination,
                               date=date,
                               price=price)
        print(response)   

    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")


def main():
    rospy.init_node('trip_publisher')

    while not rospy.is_shutdown():
        print("\n--- Travel Management System ---")
        print("1. Create Trip")
        print("2. Display All Trips")
        print("3. Search Trip")
        print("4. Update Trip")
        print("5. Delete Trip")
        print("6. Exit")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            destination = input("Enter Destination: ")
            date = input("Enter Date (YYYY-MM-DD): ")
            price = float(input("Enter Price: "))
            create_trip_client(destination, date, price)
        elif choice == 2:
            display_trips_client()
        elif choice == 3:
            search_trip_client() 
        elif choice == 4:
            trip_id = int(input("Enter Trip ID to update: "))
            new_destination = input("Enter new Destination (leave empty to keep current): ")
            new_date = input("Enter new Date (YYYY-MM-DD, leave empty to keep current): ")
            new_price = input("Enter new Price (leave empty to keep current): ")
            new_price = float(new_price) if new_price else -1.0  
            update_trip_client(trip_id, new_destination, new_date, new_price)
        elif choice == 5:
            trip_id = int(input("Enter Trip ID to delete: "))
            delete_trip_client(trip_id)
        elif choice == 6:
            print("\nExiting the program. Thanks for visiting us!")
            return
        else:
            print("\nInvalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()



# current flaw: you can search for more than 2 features, but if one of the features doesn't exist, it would still display that feature (incorrect handling of and/or condition)