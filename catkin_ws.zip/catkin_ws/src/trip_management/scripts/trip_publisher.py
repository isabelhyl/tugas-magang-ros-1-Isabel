#!/usr/bin/env python

import rospy
from trip_management.msg import trip_command  # Replace `your_package` with your actual package name

def user_command_publisher():
    pub = rospy.Publisher('trip_commands', trip_command, queue_size=10)
    rospy.init_node('user_command_publisher', anonymous=True)
    rate = rospy.Rate(1)  # 1 Hz

    while not rospy.is_shutdown():
        command = trip_command()
        
        # Example input handling; loop to take a command
        user_input = input("Enter command (create, display, update, delete, exit): ").strip()
        if user_input == "exit":
            break

        command.command = user_input

        # Collect additional fields based on the command
        if user_input == "create":
            command.destination = input("Enter Destination: ").strip()
            command.date = input("Enter Date (YYYY-MM-DD): ").strip()
            command.price = float(input("Enter Price: "))
        
        elif user_input == "update":
            command.tripID = int(input("Enter Trip ID to update: ").strip())
            command.destination = input("Enter new Destination (leave empty to keep current): ").strip()
            command.date = input("Enter new Date (leave empty to keep current): ").strip()
            command.price = float(input("Enter new Price (-1 to keep current): "))

        elif user_input in ["delete", "display"]:
            command.tripID = int(input("Enter Trip ID: ").strip())
        
        # Publish the command message
        rospy.loginfo(command)
        pub.publish(command)
        rate.sleep()

if __name__ == '__main__':
    try:
        user_command_publisher()
    except rospy.ROSInterruptException:
        pass
